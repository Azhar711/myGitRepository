﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ApiPOC.Factory
{
    public interface IUserContext
    {
        Task<IdentityUser> GetUser(string userName, string password);
    }
}